package com.example.doctorappointmentapplication;

import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;



public class MainActivity extends Activity  {


    String[] doctors= {"Mehmet Altundağ", "Ahmet Eren", "Eren Erdil", "Anıl Bozkurt", " Enes Dağdelen"};
    String[] clocks= {"09:00-10:00","10:00-11:00","11:00-12:00","13:00-14:00","14:00-15:00","15:00-16:00"};





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText fullname=(EditText) findViewById(R.id.full_name);
        final EditText citizen=(EditText) findViewById(R.id.citizen);
        final EditText phone=(EditText) findViewById(R.id.phone);
        final EditText date=(EditText) findViewById(R.id.date);

        Button nextbutton=(Button) findViewById(R.id.button);
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        final Spinner spinner2= (Spinner) findViewById(R.id.spinner2);

        //Creating the ArrayAdapter instance having the doctor and clock list

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, doctors);
        ArrayAdapter adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, clocks);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        //Setting the ArrayAdapter data on the Spinner

        spinner.setAdapter(adapter);
        spinner2.setAdapter(adapter2);

        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,
                        InfoActivity.class);
                intent.putExtra("Doctor",String.valueOf(spinner.getSelectedItem()));
                intent.putExtra("Clock",String.valueOf(spinner2.getSelectedItem()));
                intent.putExtra("FullName",String.valueOf(fullname.getText()));
                intent.putExtra("Citizenship",String.valueOf(citizen.getText()));
                intent.putExtra("Phone",String.valueOf(phone.getText()));
                intent.putExtra("Date",String.valueOf(date.getText()));



                startActivity(intent);
            }
        });

    }




}
