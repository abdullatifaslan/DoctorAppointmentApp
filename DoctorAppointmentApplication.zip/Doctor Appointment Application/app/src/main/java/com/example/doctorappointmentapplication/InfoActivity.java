package com.example.doctorappointmentapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;


public class InfoActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        Button applybutton=(Button) findViewById(R.id.button2);

        TextView doctor= (TextView) findViewById(R.id.doctor);
        TextView clocks= (TextView) findViewById(R.id.clock);
        TextView name= (TextView) findViewById(R.id.name);
        TextView citizen= (TextView) findViewById(R.id.citizen);
        TextView phone= (TextView) findViewById(R.id.phone);
        TextView date=(TextView) findViewById(R.id.date);


        Bundle bundle=getIntent().getExtras();

        final String Doctor=bundle.get("Doctor").toString();
        final String Clock=bundle.get("Clock").toString();
        final String Name=bundle.get("FullName").toString();
        String Citizen=bundle.get("Citizenship").toString();
        String Phone=bundle.get("Phone").toString();
        final String Date=bundle.get("Date").toString();



        doctor.setText(Doctor);
        clocks.setText(Clock);
        name.setText(Name);
        citizen.setText(Citizen);
        phone.setText(Phone);
        date.setText(Date);



        final ArrayList<String> list = new ArrayList<>();

            list.add(Name+ "_" +Clock+"_"+Date+"_"+Doctor);


        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1,list);

        arrayAdapter.notifyDataSetChanged();



        applybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(InfoActivity.this,ListActivity.class);

                intent.putExtra("Appointment",list);

                startActivity(intent);

            }
        });



    }
}
