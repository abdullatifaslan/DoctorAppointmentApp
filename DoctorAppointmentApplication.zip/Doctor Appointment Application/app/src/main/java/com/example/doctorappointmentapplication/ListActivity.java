package com.example.doctorappointmentapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        //Bundle bundle=getIntent().getExtras();


        final ArrayList<String> AppointmentList = getIntent().getStringArrayListExtra("Appointment");
        //final ArrayList<String> AppointmentList = (ArrayList<String>) getIntent().getSerializableExtra("Appointment");


        ListView listView=(ListView) findViewById(R.id.listview);

        final ArrayAdapter<String> appointmentdata=new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, android.R.id.text1, AppointmentList);

        listView.setAdapter(appointmentdata);



        appointmentdata.notifyDataSetChanged();



        Button btn=(Button) findViewById(R.id.button3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(ListActivity.this, MainActivity.class);
                startActivity(home);


            }
        });



    }
}
